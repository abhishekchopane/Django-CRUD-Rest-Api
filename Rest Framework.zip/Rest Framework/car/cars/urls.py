from django.urls import path
from .api import carsCreateApi,carsApi,carsDeleteApi,carsUpdateApi

urlpatterns = [
    path('api/create',carsCreateApi.as_view()),
    path('api',carsApi.as_view()),
    path('api/<int:pk>',carsUpdateApi.as_view()),
    path('api/<int:pk>/delete',carsDeleteApi.as_view()),
    ]
