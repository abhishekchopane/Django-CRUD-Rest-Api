from django.db import models

# Create your models here.
class cars(models.Model):
    carid = models.IntegerField()
    carname = models.CharField(max_length=100)
    esize = models.IntegerField()
    