from rest_framework import generics
from rest_framework.response import Response
from .serializer import carsSerializer
from .models import cars

class carsCreateApi(generics.CreateAPIView):
    queryset = cars.objects.all()
    serializer_class = carsSerializer
class carsApi(generics.ListAPIView):
    queryset = cars.objects.all()
    serializer_class = carsSerializer
class carsUpdateApi(generics.RetrieveUpdateAPIView):
    queryset = cars.objects.all()
    serializer_class = carsSerializer
class carsDeleteApi(generics.DestroyAPIView):
    queryset = cars.objects.all()
    serializer_class = carsSerializer
